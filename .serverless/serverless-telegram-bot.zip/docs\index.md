Pyppeteer's documentation
=========================

.. mdinclude:: ../README.md


Contents
--------

.. toctree::
   :maxdepth: 2

   reference
   changes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
